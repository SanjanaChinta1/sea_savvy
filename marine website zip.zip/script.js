document.addEventListener("DOMContentLoaded", () => {
    // Interactive Map Placeholder
    const mapDiv = document.getElementById("map");
    mapDiv.innerHTML = "<p>Interactive Map Coming Soon!</p>";
  
    // Real-Time Updates
    const updatesSection = document.querySelector("#updates");
    const updates = [
      "New species discovered in the Atlantic.",
      "Marine conservation event this weekend.",
      "Ocean temperatures reaching record highs."
    ];
    let updateIndex = 0;
  
    setInterval(() => {
      updateIndex = (updateIndex + 1) % updates.length;
      updatesSection.querySelector("p").textContent = updates[updateIndex];
    }, 5000);
  });
  