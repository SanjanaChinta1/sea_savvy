document.addEventListener("DOMContentLoaded", () => {
    // Function to simulate fetching data
    const fetchData = (updateType) => {
      const data = {
        "weather-updates": "Sunny with scattered clouds. Wave heights: 2-3 ft.",
        "conservation-events": "Beach cleanup scheduled at Coral Bay on Saturday.",
        "environmental-alerts": "Warning: High pollution levels detected near Gulf Shores.",
        "species-tracking": "Humpback whales spotted migrating along the coast.",
        "pollution-tracking": "Oil spill reported 20 miles off the Pacific shoreline.",
        "tide-wave-forecasts": "Low tide at 3:45 PM, waves at 4-6 ft expected."
      };
      return data[updateType];
    };
  
    // Update all sections
    const updateSections = () => {
      document.querySelectorAll(".update p").forEach((element) => {
        const updateType = element.id;
        element.textContent = fetchData(updateType);
      });
    };
  
    // Fetch and update data every 10 seconds
    updateSections();
    setInterval(updateSections, 10000);
  });
  